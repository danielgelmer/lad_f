
  # lad

  This is a code bundle for lad. The original project is available at https://www.figma.com/design/cvppvRYAZUsWn1XMD3R0dO/lad.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  